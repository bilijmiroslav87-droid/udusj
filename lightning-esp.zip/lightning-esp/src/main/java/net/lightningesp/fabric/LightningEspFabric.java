package net.lightningesp.fabric;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.lightningesp.vanilla.LightningEsp;
import net.lightningesp.vanilla.LightningLinesPipeline;
import net.minecraft.client.MinecraftClient;

/**
 * Fabric wiring for the Lightning Target ESP — no mixin required.
 *
 * Register this as your mod's client entrypoint in {@code fabric.mod.json}:
 * <pre>{@code
 * "entrypoints": { "client": [ "net.lightningesp.fabric.LightningEspFabric" ] }
 * }</pre>
 *
 * {@code WorldRenderEvents.AFTER_ENTITIES} is the right hook here: the world
 * depth buffer is already populated, so the normal pass correctly hides bolt
 * segments behind terrain while the GREATER-depth pass shows only the hidden
 * ones.
 *
 * Note that {@code WorldRenderContext.matrices()} is a world-space MatrixStack
 * and expects camera-relative vertex coordinates, which is exactly what
 * {@link net.lightningesp.core.LightningBoltGeometry} emits.
 */
public final class LightningEspFabric implements ClientModInitializer {

    /** Shared module instance so a keybind/menu can toggle it. */
    public static final LightningEsp ESP = new LightningEsp();

    @Override
    public void onInitializeClient() {
        ESP.setEnabled(true);
        // Register the render pipelines only once the resource/shader loader is
        // up. Doing it earlier throws, doing it lazily from inside a render pass
        // is unsafe.
        ClientLifecycleEvents.CLIENT_STARTED.register(client -> LightningLinesPipeline.init());

        WorldRenderEvents.AFTER_ENTITIES.register(context ->
            ESP.render(context.matrices(), MinecraftClient.getInstance().gameRenderer.getCamera())
        );
    }
}